/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package filaatendimento;

/**
 *
 * @author 82212145
 */
public class FilaAtendimento {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      
               
               
            
            TelaHome2 th= new TelaHome2();
                th.setVisible(true);
               
              
            }
        
               
    }
    

